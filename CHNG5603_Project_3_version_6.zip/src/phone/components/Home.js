// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available



//Set up the function for changing opacity.
$scope.change_opacity = function (){
  
  var studioId = 'Sparger';
  
  //Check if the opacity of the component is 1.
  if($scope.view.wdg[studioId]['opacity'] == 1){
    
    //If true, change to 0.5.
    $scope.view.wdg[studioId]['opacity'] = 0.5;
  }
  else{
    
    //If false, change back to 1.
    $scope.view.wdg[studioId]['opacity'] = 1;
  }
  
  
}


//Set up the function for the animation, it is connected to the animation button.
$scope.animation = function (){

  //Initialize values
  var timingInterval = 500;

  //1000/500=2 frame per second
  var timerId = -1;
  
  //Set counter
  var counter = 0;

  // Clear timer
  if (timerId > -1) {
    clearInterval(timerId);
  }

  // Repeat this code every time interval (i.e., every 0.5 s or 500 ms)
  timerId = setInterval(function() {
    $scope.$apply(function(){
        
      $scope.change_opacity();
      
    });
    
    //Counter plus 1.
    counter++;
    
    //Stop animation if reach 1 second (500 ms * 2).
    if (counter >= 2) {
      clearInterval(timerId);
    }
    
  }, timingInterval);
  

  
}








